export class Config {
    public static ServiceBaseUrl = 'http://localhost:8080/';
    public static projectName = 'RICH CARD';
    public static projectLogoUrl = 'assets/richcard.png';
    public static footerText = 'Copyrights Reserved';
    public static navigationType = 'horizontal-navigation';

}
