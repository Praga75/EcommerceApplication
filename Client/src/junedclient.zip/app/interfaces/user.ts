export interface User {
    userId: Number,
    userName: String,
    firstName: String,
    lastName: String,
    email: String,
    displayName: String,
    hasAddress: Boolean,
    isActive: Boolean,
    DocId: String,
    originalProfilePicFileName: String,
    profilePicMimeType: String
}

export interface Role {
}

export interface Entity {
}

export interface Operation {
}

export interface CodeTableHeader {

}

export interface CodeTable {

}
export interface Document {

}

