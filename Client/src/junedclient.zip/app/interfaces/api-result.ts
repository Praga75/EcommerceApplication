export interface ApiResult {
    pageNumber: number,
    results: [any],
    total: number 
}
