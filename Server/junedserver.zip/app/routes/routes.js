
module.exports = function(app, acl) {

	// server routes ===========================================================
	// handle things like api calls
	// authentication routes

	// frontend routes =========================================================
	// route to handle all angular requests
	// app.get('/', function(req, res) {
	// 	res.sendfile(global.baseDir  + '/index.html');
	// });

	// app.get('/externalServices', function(req, res) {
	// 	res.sendfile(global.baseDir + '/index.html');
	// });

	//app.get('*', function(req, res) {
	//	res.sendfile(global.baseDir + '/index.html');
	//});
};