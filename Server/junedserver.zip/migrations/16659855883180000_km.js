exports.up = (knex) => {
    return Promise.all([])
};
exports.down = (knex) => {
    return Promise.all([])
};